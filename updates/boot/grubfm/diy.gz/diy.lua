
varlist = 
{
		"name",
		"icon",
		"bootwin",
		"listiso",
		"listall",
		"bootfile",
		"cmd"
}

typesvar = 
{
		"menu",
        "condition",
        "title",
		"enable",
        "icon"
}

envlist =
{
        "func",
		"platform",
		"user",
        "prefix",
		"enable",
		"grubfm_path",
		"grubfm_dir",
		"grubfm_device",
		"grubfm_disk",
		"grubfm_name",
		"grubfm_filename",
		"grubfm_fileext",
	    "initmode",
	    "grubfm_setboot",
		"open",
		"condition"
}

      

function openmenu()
    for j=0,10 do
	    title= (ini.get (typesini, j, "title"))
	    icon= (ini.get (typesini, j, "icon"))
	    enable= (ini.get (typesini, j, "enable")) 
	
		if title ~= nil then
           title = (j).. "." .. (title)
		         
        end		
		if icon == nil then
           icon = "exe"
	    end
		if title ~= nil and enable ~= ("" .. platform .. "") and enable ~= ("all") then
		          title = "".. j .. "[已过滤] 不支持" .. platform .. "环境" 
          command = "echo -n 跟你说了当前环境不支持这种启动方式; sleep -i -v 3; continue;"
          grub.add_icon_menu (icon,command, title)	 
        elseif title ~= nil then	  
		command = "set func=boot; $grubfm_fileext$grub_platform=" .. j .. "; save_env -f (${cfg})/boot/grubfm/diy.cfg $grubfm_fileext$grub_platform; " ..
	    "echo -n 已设置[$grubfm_fileext]文件默认用第" .. j .. "种打开方式.......; sleep -i -v 1; clear_menu; set func=setenv; lua (diy)/diy.lua;"
        grub.add_icon_menu (icon,command,title)	
        grub.add_hidden_menu (j,command,title)		
        		
        end
	end	
end    
     
function getini(num)
    i=1
    i=i+1
    for i,myvar in ipairs(varlist) do
            getvar = (ini.get (diyini, num, myvar))
        if  getvar == nil then
            getvar = ""
        else
          --print(myvar .. "=" .. getvar)
		    grub.script ("unset " .. myvar .. "")
            grub.script ("export " .. myvar .. "=\"" .. getvar .. "\";")
	    end
		
    end
	
	--ini.free(ini)
end

function getbootbootfile()
		 j = grub.getenv ("j")
		 getini(j)

end
	 
function previous()            
		--add go-previous menu--   
		     settings() 
            icon = ("go-previous")
            name = ("返回➯[文件管理器]┇当前:DIY菜单  [按'S'设置] " .. platformname)
            command = "export theme_std=${prefix}/themes/slack/theme.txt; "
        .. "export theme_fm=${prefix}/themes/slack/fm.txt; "
        .. "export theme_help=${prefix}/themes/slack/help.txt; "
        .. "export theme_info=${prefix}/themes/slack/info.txt; grubfm"
            grub.add_icon_menu (icon, command, name)
		   
					
end            

function previousdiy()            
		--add go-previous menu--   
		    settings() 
            icon = ("go-previous")
            name = ("返回➯[DIY菜单]┇当前:设置  " .. platformname .. "  [版本:" .. diyver .. "]")
			if platform == "efi" then
	        command = "search --set=grubfm -f -q /boot/grubfm/grubfmx64.efi; chainloader -b ($grubfm)/boot/grubfm/grubfmx64.efi"
			else
			command = "search --set=grubfm -f -q /boot/grubfm/fmldr; ntldr ($grubfm)/boot/grubfm/fmldr"
			end
			grub.add_icon_menu (icon, command, name)
		   
		
end       

function settings()            
	    	hotkey = ("s")
            name = ("设置:" .. platformname .. "[版本:" .. diyver .. "]")
            command = "clear_menu; set func=setenv; lua (diy)/diy.lua"
            grub.add_hidden_menu (hotkey, command, name)
					
		
end               

function getmode(num)
    i=0
    i=i+1
    for i,myvar in ipairs(typesvar) do
            getvar = (ini.get (typesini, num, myvar))
        if  getvar == nil then
            getvar = ""
        else
          print(myvar .. "=" .. getvar)
		    grub.script ("unset " .. myvar .. "")
            grub.script ("export " .. myvar .. "=\"" .. getvar .. "\";")
	    end
		
    end
	--ini.free(ini)
end
      

function openmode()            
		--add go-previous menu--   
            icon = ("go-previous")
            name = grub.gettext ("请为扩展名为[" .. grubfm_fileext .. "]的文件设置默认打开方式:")
            command = "export theme_std=${prefix}/themes/slack/theme.txt; "
        .. "export theme_fm=${prefix}/themes/slack/fm.txt; "
        .. "export theme_help=${prefix}/themes/slack/help.txt; "
        .. "export theme_info=${prefix}/themes/slack/info.txt; grubfm"
            grub.add_icon_menu (icon, command, name)
		    
					
end 

function freemem()            
	ini.free (diyini)
    ini.free (typesini)
end 

function setenv ()            
            previousdiy() 
			if initmode == "listiso" then
			command = "set initmode=listall; save_env -f (${cfg})/boot/grubfm/diy.cfg initmode; clear_menu; set func=setenv; lua (diy)/diy.lua;"
			name = grub.gettext ("下次启动[列出ISO]")
			
			elseif initmode == "listall" then
			command = "set initmode=listall_grub2fm; save_env -f (${cfg})/boot/grubfm/diy.cfg initmode; clear_menu; set func=setenv; lua (diy)/diy.lua;"
			name = grub.gettext ("下次启动列出全盘的[ISO/WIM/VHD]文件")
			
			elseif initmode == "listall_grub2fm" then
			command = "set initmode=diymenu; save_env -f (${cfg})/boot/grubfm/diy.cfg initmode; clear_menu; set func=setenv; lua (diy)/diy.lua;"
			name = grub.gettext ("下次启动列出U盘的[ISO/WIM/VHD]文件")
			
			
			elseif initmode == "diymenu" then
			command = "set initmode=listiso; save_env -f (${cfg})/boot/grubfm/diy.cfg initmode; clear_menu; set func=setenv; lua (diy)/diy.lua;"
			name = grub.gettext ("下次启动[DIY菜单]")
			end
			icon = ("settings")           
            grub.add_icon_menu (icon, command, name)
		--grubfm_set boot 1
			if grubfm_setboot == "1" then
			command = "set grubfm_setboot=0; save_env -f (${cfg})/boot/grubfm/diy.cfg grubfm_setboot; clear_menu; set func=setenv; lua (diy)/diy.lua;"
			name = grub.gettext ("静默启动:[是]")
			grub.add_icon_menu (icon, command, name)
			
			elseif grubfm_setboot == "0" then
			command = "set grubfm_setboot=diy; save_env -f (${cfg})/boot/grubfm/diy.cfg grubfm_setboot; clear_menu; set func=setenv; lua (diy)/diy.lua;"
			name = grub.gettext ("静默启动:[否]")
			grub.add_icon_menu (icon, command, name)
			
			elseif grubfm_setboot == "diy" then
			command = "set grubfm_setboot=1; save_env -f (${cfg})/boot/grubfm/diy.cfg grubfm_setboot; clear_menu; set func=setenv; lua (diy)/diy.lua;"
			name = grub.gettext ("静默启动:[自定义]")
			grub.add_icon_menu (icon, command, name)
			
			name = grub.gettext ("wim:" .. wim)
			icon = ("wim") 
			command = "set grubfm_fileext=wim; set func=openmode; lua (diy)/diy.lua;"
			grub.add_icon_menu (icon, command, name)
			       
			name = grub.gettext ("ISO:" .. iso)
			icon = ("iso")  
			command = "set grubfm_fileext=iso; set func=openmode; lua (diy)/diy.lua;"
			grub.add_icon_menu (icon, command, name)
			
			name = grub.gettext ("VHD:" .. vhd)
			icon = ("hdd")  
			command = "set grubfm_fileext=vhd; set func=openmode; lua (diy)/diy.lua;"
			grub.add_icon_menu (icon, command, name)
			end
			
			name = ("设置菜单超时和默认")
			icon = ("settings")
			command = "load_env -f (${cfg})/boot/grubfm/diy.cfg; echo 请输入超时时间:[0-~] 当前[$timeout]; read timeout; save_env -f (${cfg})/boot/grubfm/diy.cfg timeout; "
			.. "clear; echo 请输入默认选中的菜单:[0-~] 当前[$default]; read default; save_env -f (${cfg})/boot/grubfm/diy.cfg default; "
			.. "clear_menu; set func=setenv; lua (diy)/diy.lua;"
			grub.add_icon_menu (icon, command, name)
             
		
			name = ("在线升级")
			icon = ("net")  
			command = "set func=upgrade; lua (diy)/diy.lua;"
			grub.add_icon_menu (icon, command, name)
			
			name = ("重置版本号【用于强制升级】")
			icon = ("reboot")  
			command = "set diyver=10086; save_env -f (${cfg})/boot/grubfm/ver diyver; clear_menu; set func=setenv; lua (diy)/diy.lua"
			grub.add_icon_menu (icon, command, name)
          
end

function bootmenu()
    for i=1,20 do
	j=(platform .. "" .. i)
	    name= (ini.get (diyini, j, "name"))
	    icon= (ini.get (diyini, j, "icon"))
	    bootfile= (ini.get (diyini, j, "bootfile"))
		bootwin= (ini.get (diyini, j, "bootwin"))
		listiso= (ini.get (diyini, j, "listiso")) 
		listall= (ini.get (diyini, j, "listall")) 
		cmd= (ini.get (diyini, j, "cmd")) 
		
	
		if name == nil then
           name = (i) .. ".[空]"
		else 
           name = (i).. "." .. (name)
        end		
		if icon == nil then
           icon = "exe"
	    end
		if name ~= nil and bootfile ~= nil and cmd == nil and grubfm_setboot ~= "diy" then
           command = "set func=boot; j=" .. j .. "; lua (diy)/diy.lua"   
           grub.add_icon_menu (icon,command, name)
		   
		elseif name ~= nil and bootfile ~= nil and cmd == nil and grubfm_setboot == "diy" then
           command = "set func=diyboot; j=" .. j .. "; lua (diy)/diy.lua"   
           grub.add_icon_menu (icon,command, name)	      
		   
		elseif bootwin ~= nil then
		   command = "set func=bootwin; j=" .. j .. "; lua (diy)/diy.lua"   
           grub.add_icon_menu (icon,command, name)
		   
		elseif listiso ~= nil then
           command = "set func=listiso; j=" .. j .. "; lua (diy)/diy.lua"   
           grub.add_icon_menu (icon,command, name)
		   
		elseif listall ~= nil then
           command = "set func=listall; j=" .. j .. "; lua (diy)/diy.lua"   
           grub.add_icon_menu (icon,command, name)   
		   
		elseif cmd ~= nil then
           command = "set func=diycmd; j=" .. j .. "; lua (diy)/diy.lua"   
           grub.add_icon_menu (icon,command, name)
        
     
        end
	end	
end    
        --getenv
        func = grub.getenv ("func")
		platform = grub.getenv ("grub_platform")
		user = grub.getenv ("user")
        diyini = grub.getenv ("diyini")
		diyver = grub.getenv ("diyver")
 		initmode = grub.getenv ("initmode")
	    wim = grub.getenv ("wim" .. platform .. "")
		iso = grub.getenv ("iso" .. platform .. "")
		vhd = grub.getenv ("vhd" .. platform .. "")
		grubfm_setboot = grub.getenv ("grubfm_setboot")
	    prefix = grub.getenv ("prefix")
		enable = grub.getenv ("enable")
		grubfm_path = grub.getenv ("grubfm_path")
		grubfm_dir = grub.getenv ("grubfm_dir")
		grubfm_device = grub.getenv ("grubfm_device")
		grubfm_disk = grub.getenv ("grubfm_disk")
		grubfm_name = grub.getenv ("grubfm_name")
		grubfm_filename = grub.getenv ("grubfm_filename")
		grubfm_fileext = grub.getenv ("grubfm_fileext")
	    timeout = grub.getenv ("timeout")
		default = grub.getenv ("default")		
		initmode = grub.getenv ("initmode")
	  	condition = grub.getenv ("condition")
		open = grub.getenv ("open")  
		diyini = ini.load (diyini)
	    typesini = ini.load (prefix .. "/types/" .. grubfm_fileext)
		
		if platform == "efi" then
		platformname = "[UEFI]"
		else 
		platformname = "[Legacy BIOS]"
		end
        if func == nil then
        print("no command!!")
		
		elseif func == "bootmenu" then
	    grub.script ("clear_menu")
		previous()		
      	bootmenu()
		settings()
		freemem()

		elseif func == "listiso" then
	    getbootbootfile()
		grub.script ("source $prefix/search.sh; clear_menu")
		previousdiy()
        settings()
		freemem()
		grub.script ("echo 查找iso文件...; for grubfm_current_path in (*)/; do search_list \"iso\" \"iso\"; done;")
		
        elseif func == "listall" then
		getbootbootfile()
		grub.script ("source $prefix/search.sh; clear_menu")
		previousdiy()
        settings() 
		freemem()
	    grub.script ("echo 正在全盘查找可启动文件...; for grubfm_current_path in (*)/; do search_list \"iso\" \"iso\"; " 
		.. "search_list \"wim\" \"wim\"; search_list \"vhd\" \"img\"; search_list \"vhdx\" \"img\"; done;")
		
		
		elseif func == "listall_grub2fm" then
		getbootbootfile()
		grub.script ("source $prefix/search.sh; clear_menu")
		previousdiy()
        settings() 
		freemem()
	    grub.script ("echo 正在查找U盘上的可启动文件...; search --set=grub2fm --label GRUB2FM; export grub2fm=$grub2fm; search --set=grub2efi --label GRUB2EFI; "
		.. "export grub2efi=$grub2fm; for grubfm_current_path in ($grub2fm)/; do search_list \"iso\" \"iso\"; " 
		.. "search_list \"wim\" \"wim\"; search_list \"vhd\" \"img\"; search_list \"vhdx\" \"img\"; done;")
		 		 		
		elseif func == "bootwin" and platform == "pc" then
	    getbootbootfile()
		freemem()
	    grub.script ("echo 启动windows...; search --set=path -f -q /bootmgr; echo ($path)bootmgr; ntldr \"($path)/bootmgr\";")
		
		elseif func == "setenv" then
		setenv()
		freemem()
		
	    elseif func == "bootwin" and platform == "efi" then
	    getbootbootfile()
		freemem()
	    grub.script ("echo 启动windows...; search --set=path -f -q /EFI/Microsoft/Boot/bootmgfw.efi; echo ($path)/EFI/Microsoft/Boot/bootmgfw.efi; "
		.. "chainloader -b -t \"($path)/EFI/Microsoft/Boot/bootmgfw.efi\";")
		
		elseif func == "diyboot" then
	    getbootbootfile()
		freemem()
	    grub.script ("echo 启动$bootfile...; search --set=path -f -q $bootfile; export grubfm_file=($path)$bootfile; source $prefix/func.sh; "..
		"export grubfm_file=$grubfm_file; export grubfm_fileext=$grubfm_fileext; export openenv=$grubfm_fileext$grub_platform")
		open = grub.getenv("openenv")
        open = grub.getenv(open)
        grub.script ("export open=" .. open .. "; set func=rundiyboot; lua (diy)/diy.lua")
		
		elseif func == "openmode" then
	    grub.script ("clear_menu")
		openmode()		
      	openmenu()
		settings()
		freemem()
		
		elseif func == "rundiyboot" and condition == nil then
		getmode(open)
		freemem()
	    grub.script ("echo 文件类型$grubfm_fileext,打开方式$open; configfile $prefix/rules/$menu;")
		
		elseif func == "rundiyboot" and condition ~= nil then
		getmode(open)
		freemem()
	    grub.script ("configfile $prefix/rules/$condition;")
		
		
		elseif func == "rundiyboot" and open == nil then
		getbootbootfile()
		freemem()
	    grub.script ("echo 启动$bootfile...; search --set=path -f -q $bootfile; echo ($path)$bootfile; grubfm_open \"($path)$bootfile\";")
			
		elseif func == "boot" then
	    getbootbootfile()
		freemem()
	    grub.script ("echo 启动$bootfile...; search --set=path -f -q $bootfile; echo ($path)$bootfile; grubfm_open \"($path)$bootfile\";")
		
		elseif func == "upgrade" and platform == "efi" then
	    grub.script ("chainloader -b (diy)/upgrade.$grub_platform;")
			
		elseif func == "upgrade" and platform == "pc" then
	    grub.script ("linux16 (diy)/upgrade.$grub_platform;")
		
		
	    elseif func == "diycmd" then
	    getbootbootfile()
		freemem()
	    grub.script ("eval $cmd")
		
	    end 

